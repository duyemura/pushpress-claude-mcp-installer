---
name: explore
description: >
  Show what's possible with Claude Cowork for the PushPress team. Use when someone says
  "what can you do", "what can I do with this", "show me what's possible", "help me explore",
  "what tools do I have", "I'm new to this", "walk me through what you can help with",
  or anything like "give me ideas for how to use Claude".
triggers:
  - "what can you do"
  - "what can I do"
  - "show me what's possible"
  - "help me explore"
  - "I'm new to this"
  - "give me ideas"
  - "what are you capable of"
  - "what tools do I have"
  - "walk me through"
---

# Explore: What Can Claude Cowork Do?

When this skill is triggered, give the user a rich, enthusiastic tour of everything available. The guide should feel exciting and personal — not like a product manual.

## Before responding, check what's connected

Run this check to know which tools to highlight:

```bash
python3 -c "
import os, json

def get_env():
    home = os.environ.get('HOME', '/root')
    path = os.path.join(home, 'mnt', '.claude', 'settings.json')
    if not os.path.exists(path):
        path = os.path.expanduser('~/.claude/settings.json')
    try:
        with open(path) as f:
            return json.load(f).get('env', {})
    except:
        return {}

env = get_env()
has_gymhappy = bool(env.get('GYMHAPPY_MCP_TOKEN'))
has_metabase = bool(env.get('METABASE_URL')) and bool(env.get('METABASE_API_KEY'))
print(f'GYMHAPPY={has_gymhappy}')
print(f'METABASE={has_metabase}')
"
```

Use the output to personalize the response — show richer examples for connected tools, and note setup steps for unconnected ones.

## Structure of your response

Lead with energy. Something like:

> **Here's what we can do together** — and honestly, this barely scratches the surface once you get rolling.

Then walk through sections. See `references/connections.md` for the full details on each connection type, and `references/inspiration.md` for dynamic example prompts per section.

### Section 1: Your Connected Apps

Cover what apps can be connected and what they unlock. Highlight connected ones prominently, briefly mention unconnected ones as "also available." See `references/connections.md`.

### Section 2: Research & Knowledge Work

Explain how to combine web search with internal data — Slack threads, Notion docs, Google Drive files — to build research reports that no one could pull together manually. Examples from `references/inspiration.md`.

### Section 3: GymHappy Support Tools

**Only expand this section if GYMHAPPY=True.** If not connected, briefly mention: "Once you add your GymHappy token, I can do full gym support work."

If connected, go deep: gym lookups, reviewer diagnostics, message history, review request logs, setup checklists, feature requests, account deactivation, etc. Use 3–4 vivid examples.

### Section 4: Metabase & Data Analytics

**Only expand this section if METABASE=True.** If not connected, briefly mention: "Connect Metabase and I can answer data questions in plain English."

If connected, go deep with fun, cross-tool examples (see `references/inspiration.md` for the good ones). Emphasize that you can marry Metabase data with Slack, Notion, Gmail to find patterns nobody could find manually.

### Section 5: File & Document Work

Claude can create and edit Word docs, PowerPoint decks, Excel spreadsheets, and PDFs. Mention reading existing files too.

### Section 6: Scheduling & Automation

Mention the ability to create scheduled tasks — things that run automatically on a schedule (daily briefings, weekly reports, etc.).

## Tone notes

- Be energetic and concrete — give specific example prompts, not vague descriptions
- Use natural language, not a bulleted feature list
- Make the cross-tool examples feel magical — these are the "wow" moments
- End with an invitation: "Want me to dive into any of these? Just ask."

## Reference files

- `references/connections.md` — detailed notes on each app integration
- `references/inspiration.md` — curated example prompts for each category, including the fun cross-tool Metabase examples
