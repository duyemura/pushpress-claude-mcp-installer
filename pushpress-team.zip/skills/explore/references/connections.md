# App Connections Reference

This file describes what each connected app unlocks in Claude Cowork. Use this to populate the "Connected Apps" section of the explore skill response.

---

## Gmail

**How to connect**: The Gmail connector is available in Cowork's MCP connector marketplace.

**What it unlocks**:
- Search and read emails ("find all emails from [person] about [topic]")
- Draft and send emails
- Summarize email threads
- Find follow-ups you forgot to send
- Build reports that incorporate email data

**Example prompts**:
- "Find all emails about the gym migration project and give me a summary"
- "Draft a follow-up to the thread with John about the API issue"
- "What's been in my inbox about churn this week?"

---

## Google Calendar

**How to connect**: Available in the Cowork MCP connector marketplace.

**What it unlocks**:
- Check your schedule
- Create events and invites
- Find free time for meetings
- See what's coming up and prep for meetings

**Example prompts**:
- "What do I have tomorrow?"
- "Schedule a 30-min call with Dan next Tuesday afternoon"
- "Find a time this week when both I and Sarah are free for an hour"

---

## Notion

**How to connect**: Available in the Cowork MCP connector marketplace.

**What it unlocks**:
- Search and read Notion pages and databases
- Create and update pages
- Find internal docs, wikis, project plans
- Combine Notion knowledge with web research or Metabase data

**Example prompts**:
- "Find our onboarding doc for new GymHappy customers"
- "What decisions have we made about the pricing page in Notion?"
- "Create a meeting notes page for today's call"

---

## Slack

**How to connect**: Available in the Cowork MCP connector marketplace.

**What it unlocks**:
- Search Slack messages across channels
- Read threads and channel history
- Draft messages for review before sending
- Find decisions, context, and discussions that live in Slack

**Example prompts**:
- "What's been discussed about the billing overhaul in Slack this week?"
- "Find the thread where we talked about Gym X's refund request"
- "Draft a message to #product-team about the new GymHappy feature"

---

## Google Drive

**How to connect**: Available in the Cowork MCP connector marketplace.

**What it unlocks**:
- Search and read Google Docs, Sheets, and other Drive files
- Combine Drive content with other data sources

**Example prompts**:
- "Find the Q4 strategy doc in Drive and summarize the key priorities"
- "Read the competitive analysis we did last quarter"

---

## GymHappy (MCP)

**How to connect**: Run `/setup-keys` and provide your GYMHAPPY_MCP_TOKEN.

**What it unlocks** (full support tools):
- Look up any gym by name, slug, or email
- Look up members/reviewers — review history, DND status, message log
- Diagnose why a member isn't getting messages (eligibility checker)
- View review request logs, message send history
- Check setup checklists for new accounts
- Monitor HighLevel sync issues and workflow errors
- Make account changes: display name, report email, send window, DND flags, review visibility
- Onboard new gyms with `/pp-install-gymhappy`

---

## Metabase (MCP)

**How to connect**: Run `/setup-keys` and provide METABASE_URL + METABASE_API_KEY.

**What it unlocks**:
- Query the PushPress data warehouse in plain English
- Browse dashboards and saved cards
- Get stats on gyms, revenue, churn, engagement, feature usage
- Combine with Slack/Notion/Gmail to find patterns across data sources

---

## Web Search

**Always available** — no setup needed.

**What it unlocks**:
- Real-time web research on any topic
- Competitor research, market analysis
- News, documentation, product info
- Combine web research with internal data for hybrid reports
