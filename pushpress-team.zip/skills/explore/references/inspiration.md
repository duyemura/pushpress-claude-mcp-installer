# Inspiration: Example Prompts by Category

Use these when writing the explore skill response. These are the examples that make people's eyes light up — especially the cross-tool ones.

---

## Research & Knowledge Work

These show the power of combining web search with internal tools:

- "Research what CrossFit gyms are doing differently for member retention, then cross-reference with our top-performing gyms on Metabase to see if the patterns match"
- "Give me a summary of everything in Notion and Slack about the pricing change we discussed last month, plus any relevant industry news"
- "Find everything we know about [Competitor Name] — their pricing, recent news, and any mentions in our Slack — and put it in a one-page brief"
- "Pull together a competitive analysis on our top 3 competitors using web research, then write it up as a doc I can share with the team"
- "What's been happening in fitness tech this week? Any news that's relevant to us?"

---

## Gmail + Calendar

- "Summarize my email threads with [person] and give me talking points for our call tomorrow"
- "Find all the open action items from my email over the last two weeks that I haven't followed up on"
- "Draft a response to [email thread] that's professional but concise"
- "What's on my calendar tomorrow and is there anything I should prep for?"

---

## Slack Research

- "What did the team decide about [topic] in Slack over the last month?"
- "Find any Slack threads where customers complained about [feature] and summarize the main issues"
- "Who's been talking to [Gym Name] in Slack and what's the latest?"
- "Summarize #support-escalations from this week and flag anything that needs follow-up"

---

## GymHappy Support (only show if GYMHAPPY=True)

Vivid, specific examples of what you can actually do:

- "Look up CrossFit South End — why aren't their members getting review requests?"
- "Find all gyms that signed up in January but haven't gotten a single review yet"
- "Check the message log for sarah@brightfitness.com — has she ever been sent a review request?"
- "Run the full setup checklist on Peak Performance Gym and tell me what's missing"
- "Show me recent 1-star reviews across our biggest accounts so I can flag them"
- "A gym owner is complaining their display name is wrong — fix it"
- "Which gyms have had HighLevel workflow errors in the last 24 hours?"

---

## Metabase & Data (only show if METABASE=True)

These are the fun cross-tool examples that combine Metabase data with Slack, Notion, Gmail:

**Standalone Metabase:**
- "What are our top 25 gyms by MRR right now?"
- "Show me churn rate by month for the last year — is it getting better or worse?"
- "How many gyms are on the GymHappy add-on? Break it down by plan tier"
- "Which gyms haven't logged into the app in 60+ days? I want to run a re-engagement campaign"
- "What's the average number of members per gym, and how does that compare across plans?"

**Cross-tool magic (the wow moments):**
- "Pull the top gyms by revenue from Metabase, then search Slack to see which ones the CEO has been talking about recently — are we paying enough attention to our best customers?"
- "Find gyms that churned in the last 90 days in Metabase, then search our Notion for any notes about those accounts, and give me a theory about why they left"
- "Which gyms are growing fastest according to Metabase? Now check if any of them are mentioned in our #wins Slack channel — let's see if we're celebrating our best growth stories"
- "Show me gyms that have been on the platform for 2+ years but never tried GymHappy. Then search Notion for any product feedback about why gyms don't upgrade, so I can put together a targeted re-engagement pitch"
- "Pull this month's new gym signups from Metabase. Cross-reference with my Gmail to see if I've had any onboarding calls with any of them. Flag the ones I haven't touched yet"
- "Find gyms in Texas with 200+ members from Metabase, then search Slack for any conversations about Texas expansion or events — maybe we can tie outreach to something relevant"
- "What does our typical churned gym look like? (size, plan, tenure) — build me a churn risk profile from Metabase, then I'll use it to write a re-engagement email sequence"

---

## File & Document Work

- "Create a Word doc summarizing this quarter's GymHappy performance — I'll share it with the board"
- "Build a PowerPoint deck for our next all-hands with 6 slides covering [topics]"
- "Make an Excel tracker for gym onboarding status with columns for [fields]"
- "Read this PDF contract and flag any unusual terms"
- "Turn these bullet points into a polished one-pager I can send to a prospect"

---

## Scheduled Tasks & Automation

- "Set up a daily briefing that runs at 8am — pull my calendar, any urgent Slack mentions, and GymHappy workflow errors overnight"
- "Create a weekly Metabase report that runs every Monday and emails me the top churn risk accounts"
- "Schedule a task that checks for new 1-star GymHappy reviews every morning and summarizes them"

---

## Closing line for the explore response

End the explore response with something like:

> These are just starting points — the best prompts are usually the ones specific to what you're working on right now. What are you trying to figure out?
