---
name: pp-bug-check
description: Investigate whether a customer-reported issue is a bug by searching the PushPress codebase.
tools:
  - Bash
  - Read
---

# /pp-bug-check

Help the CX team determine if a customer-reported issue is a bug, expected behavior, or needs engineering review.

---

## Step 1 — Check GitHub MCP

Try to use a GitHub MCP tool — search for something trivial like `pushpress` in the org. If the tools aren't available or return auth errors, show this and stop:

> **GitHub isn't connected yet.** To use bug-check, you need the GitHub MCP.
>
> **Quick setup (takes ~2 min):**
> 1. Get the GitHub App private key from 1Password (search **"PushPress Cowork Code Reader"**)
> 2. Run this in Terminal:
>    ```
>    curl -fsSL https://raw.githubusercontent.com/duyemura/pushpress-claude-mcp-installer/main/install.sh | bash
>    ```
> 3. Choose **GitHub** when prompted and paste the private key
> 4. Restart Claude Desktop

---

## Step 2 — Gather the issue

If the user already described the issue in their message, extract what you can. Otherwise ask:

1. **What did the customer report?** — Their exact complaint
2. **Which part of PushPress?** — Classes, check-ins, billing, member app, staff app, control panel, etc.
3. **What should happen vs. what is happening?**
4. **Any error messages?** — Exact text if they have it

Keep this conversational — don't make it feel like a form.

---

## Step 3 — Map to repos

Focus your search on the right repos based on the product area:

| Product area | Primary repo(s) |
|---|---|
| Core API, webhooks, platform | `PushPress-Services` |
| Classes, scheduling, reservations | `PushPress-Services` |
| Billing, payments, enrollments | `PushPress-Services` |
| Check-ins | `PushPress-Services` |
| Control panel (gym admin dashboard) | `PushPress-Services` |
| Member mobile app | `pushpress-member-app` |
| Staff mobile app | `pushpress-staff-app` |
| Landing pages | `core-landing-pages` |
| AI features | `PushPressAI` |
| Belt / rank tracking | `belt-rank-tracker` |
| Committed club | `committed-club` |

If unsure which area, search across the `pushpress` org.

---

## Step 4 — Investigate

Use GitHub tools to build your case. Do these in order:

1. **Search for the feature** — Find the code that handles the reported behavior. Search for relevant endpoint names, function names, or error messages.

2. **Read the code** — Don't just find it, read it. Understand the logic, the conditions, the edge cases. Follow the flow from API endpoint to database query if needed.

3. **Check recent changes** — Search for PRs merged in the last 30 days that touched the relevant files. Regressions from recent deploys are a common cause. Look at both the PR description and the diff.

4. **Search for known issues** — Check if similar issues or PRs exist. Someone might have already reported or fixed this.

---

## Step 5 — Deliver the verdict

Present findings in this format:

> ### Bug Check: [one-line summary]
>
> **Verdict:** [one of the options below]
>
> - **Bug** — The code isn't doing what it should. This needs a fix.
> - **Working as designed** — The code is doing exactly what it's supposed to. The customer may need guidance on how the feature works.
> - **Needs engineering review** — I found the relevant code but can't determine from code alone whether this is a bug. Engineering should look at the runtime behavior or data.
> - **Inconclusive** — I couldn't find the relevant code or enough evidence to make a call.
>
> **What I found:**
> [Plain English explanation of what the code does and why you reached your verdict. NO code snippets — translate everything.]
>
> **Recent changes:**
> [Any relevant PRs or commits from the last 30 days, or "No recent changes to this area."]
>
> **Confidence:** High / Medium / Low
>
> **Suggested next steps:**
> - [What to tell the customer]
> - [Whether to create a Linear ticket, and what team/label]
> - [Any workaround to suggest in the meantime]

---

## Important rules

**Write for CX, not engineers.** Never paste code in the response. Instead of "the `validateCheckin()` function returns early when `memberStatus !== 'active'`", say: "The system only allows active members to check in. If a member's status recently changed, that would explain why check-in stopped working."

**Be honest about confidence.** If the code looks right but the customer has a real problem, it could be a data issue, config problem, or environment-specific. Say "needs engineering review" — that's a useful answer.

**Flag regressions.** If a recent PR changed the relevant code, call it out by name and author. This dramatically speeds up engineering triage.

**Don't speculate beyond the code.** You can see source code, not runtime behavior, database state, or customer-specific configuration. Stay within what you can actually verify.

**Suggest a Linear ticket when appropriate.** If it looks like a bug or needs engineering review, recommend creating a ticket with the team that owns the relevant code.
