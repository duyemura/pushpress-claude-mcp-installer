---
name: pp-morning-edition
description: Start your day with a PushPress morning briefing — company updates, key metrics, a Cowork tip, and a message from leadership.
---

# /pp-morning-edition

Deliver a structured morning briefing for the PushPress team. Work through each step in order, gracefully skipping any section whose source isn't configured or connected.

---

## Step 1: Load Config

Read the file `config/morning-brief.md` inside this plugin's directory. It defines:
- Which Slack channels to digest
- CEO message source (Slack channel name or Notion URL)
- Metrics source (Metabase metric IDs or a Notion page URL)
- Standing PushPress context (current priorities, OKRs, etc.)

If the config file can't be found, proceed with the Slack channels and sources listed as defaults below, and note at the top of the brief that the config hasn't been customized yet.

---

## Step 2: Slack Channel Digests

For each channel listed under `slack_channels` in the config, pull the last 24 hours of activity using the Slack tools. Summarize key updates, decisions, shipping news, and anything the whole team should know. Skip routine chatter. Flag anything urgent.

Group by channel in the output. If a channel had no notable activity, say so in one line rather than omitting it — that signal matters too.

---

## Step 3: From the Desk of Dan

Check the source defined in config under `ceo_message_source`:

- If it's a **Slack channel name** (e.g. `#morning-edition`): fetch the most recent message posted there and include it prominently.
- If it's a **Notion URL**: fetch that page and include its content.
- If the source is not configured, or there's no recent message, skip this section entirely — no placeholder, no note.

---

## Step 4: Metrics Snapshot

Check config for `metrics_source`:

- If a **Notion URL** is set: fetch that page. This is the pre-pulled metrics snapshot (populated by a separate scheduled task). Include it as-is.
- If no Notion URL is set but **Metabase is connected**: pull metrics using the approach below.
- If neither is available: include a single line — *"📊 Metrics not yet connected — ask Dan about setting up the metrics snapshot."*

### Metabase Pull Strategy

**IMPORTANT: Use cached card IDs when available — do NOT search Metabase.**

Check if `metric_card_ids` is populated in the config. If it is, execute those cards directly by ID using `execute_card()` — one group at a time, in order. Do NOT call list_cards, search_content, or load any dashboard. The discovery phase is expensive and will exhaust the context window.

Execution order (call each group sequentially, not all at once):
1. Execute `churn` card IDs → extract this week, this month, vs last month, vs plan
2. Execute `arr` card IDs → extract current ARR value and WoW/MoM/YoY trend
3. Execute `logos` card IDs → extract active logo count and WoW/MoM/YoY trend
4. Execute `martial_arts` card IDs → extract MA ARR and logos
5. Execute `net_new_mrr` card IDs → extract MTD net new MRR

If a card returns no data or an error, skip it silently. If ALL cards in a group fail, omit that group from the brief.

If `metric_card_ids` is NOT present in config (first run or cache miss), fall back to searching Metabase starting from the `dashboard_url` — but note this is slow. After a successful run, add discovered card IDs to the config.

Display metrics in four distinct groups:

**1. Customer Value**
- NPS
- GMV (total)
- GMV Per Active Logo

**2. Company Value**
- ARR (with WoW, MoM, YoY growth)
- Logos / Active Gym Accounts (with WoW, MoM, YoY growth)

**3. Martial Arts — TAM Initiative**
- ARR (with WoW, MoM, YoY growth)
- Logos (with WoW, MoM, YoY growth)

**4. 🔴 IN FOCUS: Churn**
Always show this section prominently. Include:
- Churn this week
- Churn this month
- vs Last Month (direction + delta)
- vs Plan (over/under, % variance)

Format each metric compactly — value on one line, growth delta on the next if available.
Use ↑ (green) for improvement and ↓ (red) for decline, but note that for churn, DOWN is good.
If a specific metric can't be found in Metabase, skip it without calling it out.

---

## Step 5: Cowork Tip of the Day

Read `config/cowork-tips.md` from the plugin directory. Select one tip using day-of-week rotation (Monday = tip 1, Tuesday = tip 2, cycling back after the last). Format it as a short, actionable callout.

---

## Step 6: Assemble and Deliver the Brief

Format the output exactly like this:

```
☀️  PUSHPRESS MORNING EDITION
[Day, Date]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📣  FROM THE DESK OF DAN
[CEO message — or omit this entire section if none]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🏢  COMPANY UPDATES
[Per-channel summaries from Slack — group by channel]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊  METRICS SNAPSHOT

  CUSTOMER VALUE
  · NPS              [value]
  · GMV              [value]
  · GMV / Logo       [value]

  COMPANY VALUE
  · ARR              [value]  [↑/↓ WoW · MoM · YoY]
  · Logos            [value]  [↑/↓ WoW · MoM · YoY]

  MARTIAL ARTS  (TAM Initiative)
  · ARR              [value]  [↑/↓ WoW · MoM · YoY]
  · Logos            [value]  [↑/↓ WoW · MoM · YoY]

  🔴  IN FOCUS — CHURN
  · This Week        [value]
  · This Month       [value]
  · vs Last Month    [↑/↓ delta]
  · vs Plan          [over/under + % variance]

[If metrics unavailable: "📊 Metrics not yet connected — ask Dan about setting up the metrics snapshot."]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡  TODAY'S COWORK TIP
[Tip of the day]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

Keep the brief scannable. Bullets over paragraphs. Links where available. Aim for something someone can read in 2 minutes.

---

## Step 7: Schedule Prompt — ALWAYS RUN THIS

After delivering the brief, check whether a scheduled task named `pp-morning-edition` already exists using the scheduled tasks tools.

**If already scheduled:**
End with:
> ✅ *Your Morning Edition is scheduled. See you tomorrow.*

**If NOT scheduled:**
ALWAYS end with this prompt, no exceptions:

---

> ⏰ **Make this your daily habit.**
>
> Want your Morning Edition waiting for you automatically every weekday? I can set it up right now.
>
> Just say **"Yes, schedule it"** — or tell me a time like **"Yes, 7:30am"** — and I'll handle the rest. Default is **8:00 AM weekdays**.

---

If the user confirms (any variation of "yes", "schedule it", "do it", or provides a time), immediately create a scheduled task:
- **Task ID:** `pp-morning-edition`
- **Description:** `PushPress Morning Edition — daily team briefing`
- **Cron:** Weekdays at their chosen time, or `0 8 * * 1-5` as default (8am Mon–Fri local time)
- **Prompt:** `Run /pp-morning-edition and deliver the full morning briefing.`

Confirm the schedule after creating it with a one-liner like:
> ✅ *Scheduled! Your Morning Edition will run automatically at 8:00 AM, Monday through Friday.*
