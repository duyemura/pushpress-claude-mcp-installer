---
name: pp-install-mcp
description: Show which PushPress MCPs are connected in Cowork, and how to install them in Claude Desktop.
tools:
  - Bash
  - Read
---

# /pp-install-mcp

Check which PushPress MCPs are active in Cowork, then offer the one-command installer for Claude Desktop.

---

## Step 1 — Load MCP definitions

Read the MCP registry to know what's supported:

```bash
cat ~/mnt/Cowork/mcp-installer/mcps.json 2>/dev/null || echo "NOT_FOUND"
```

If `NOT_FOUND`, skip to Step 3 and show the installer only.

---

## Step 2 — Check credential status

Read the Cowork settings file to check which credentials are saved:

```bash
cat ~/mnt/.claude/settings.json 2>/dev/null || echo "{}"
```

For each MCP in mcps.json, check whether the required credentials exist in the `env` object of settings.json:
- **GymHappy Support**: needs `GYMHAPPY_MCP_TOKEN`
- **Metabase**: needs `METABASE_API_KEY` (and optionally `METABASE_URL`)

Derive the credential names from the `install.env` entries where `prompt_user` is true, plus for `mcp_remote` strategies the credential is referenced in the `credential_prompt`.

---

## Step 3 — Display status

Format the output as a clean status block:

> **PushPress MCP Status**
>
> ✅ GymHappy Support — Look up gyms, members, reviews, and diagnose issues
> ❌ Metabase — Query PushPress data and pull live metrics
>    _Missing: METABASE_API_KEY_

- ✅ = all credentials present in Cowork settings
- ❌ = one or more credentials missing

If everything is ✅, say: "All PushPress MCPs are connected in Cowork."

If anything is ❌, say:
> These MCPs aren't connected yet. To install them in Cowork **and** Claude Desktop, run this in Terminal:

---

## Step 4 — Show the installer (always)

Always end with this block, regardless of status:

> **Install or update MCPs in Claude Desktop:**
>
> ```
> curl -fsSL https://raw.githubusercontent.com/duyemura/pushpress-claude-mcp-installer/main/install.sh | bash
> ```
>
> No Python or Homebrew needed — the installer handles everything, including Node.js if you don't have it. Safe to re-run.
