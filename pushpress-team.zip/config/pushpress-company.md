# PushPress Company Context
<!-- Pre-seeded into every new employee's memory/context/ during onboarding via pp-onboard-me -->
<!-- Last updated: 2026-02-28 — Sources: Notion (Mission/Vision, Tenets, Long-Term Vision, OKRs, Timeline), Dan Uyemura interview -->
<!-- Related files: pushpress-strategy.md (OKRs, Annual Plan, Initiatives) | pushpress-icp.md (ICP tiers, scoring, gym type data) -->

---

## Mission & Vision

**Mission:** Create a healthier world by helping boutique gyms run stronger businesses.

**Vision:** We envision a world where local fitness studios use technology to connect, not isolate — and turn fitness into something people crave, not avoid, by making it social, fun, and easy.

**Strategic ambition:** Be the definitive leader in Gym Management Software; connect a fragmented industry into a platform where operators, members, and the broader fitness ecosystem interact seamlessly.

---

## Founding Story

PushPress was founded by **Dan Uyemura**, **Chris McConachie**, and **Brian Aung** — all gym operators, not boardroom strategists.

Dan was a career web engineer laid off from MySpace in 2010. He had discovered CrossFit in 2008, describing it as "a technology" — a method so effective it felt like a scientific breakthrough. He used his severance to open a gym with partners; one of those partners became his co-founder.

He started coding PushPress in **2011**. His take on the market: "all software was lacking from a modern lens." He had a rare trifecta — entrepreneurialism, deep fitness understanding, and engineering skill. The company launched inside their own gyms (Torrance Training Lab and Shadow CrossFit) in **2013**, dogfooding the product before offering it to others.

The name comes from its origin: PushPress was initially built as a WordPress plugin. "Push" (vs. pull) + "Press" (WordPress) = PushPress. They scrapped the WordPress dependency, but the name stuck.

**Culture from day one:** Support is part of the product. They hired gym owners because those who truly understand the intricacies of running a fitness business are entrenched in the industry in a way outsiders aren't. This operator-first DNA is PushPress's strongest brand moat.

---

## Company Timeline

| Date | Event | Notes |
|------|-------|-------|
| 2011 | Dan starts coding PushPress | Built out of frustration with existing gym software |
| 2013-04-01 | Donut Store / Public Launch | Launched inside Torrance Training Lab and Shadow CrossFit |
| 2011-08-24 | PushPress, Inc. (CA) Formation | Incorporated as CA S Corp |
| 2019-11-22 | Freemium Launch | Strategic shift — free tier introduced |
| 2020-07-01 | Branded App Launch | $97/month white-label app offering |
| 2021-02-24 | Grow Beta Launch | CRM / lead management product enters beta |
| 2021-03-10 | PushPress, Inc. (DE) Formation | Converted to DE C Corp (standard VC-ready structure) |
| 2021-03-24 | Seed Funding | First institutional capital raised |
| 2021-07-01 | Lightning Beta | Minor product release |
| 2021-08-01 | Grow Launch | CRM/marketing product officially launched |
| 2021-10-20 | CrossFit APN Launch | Authorized Partner Network — major channel/distribution deal |
| 2021-10-26 | PowerUp Fall 2021 | Community Feed, Core Data improvements, Train announced |
| 2022-01-01 | SaaS Price Increase | Core Pro: $139 → $159; Core Max introduced at $229 |
| 2022-03-31 | PowerUp Spring 2022 | Personal Training (Appointments + Train), NCFIT programming, rebuilt Reporting |
| 2022-05-01 | Train Launch | Personal training / programming product launched |
| 2022-07-28 | Series A Funding | Major growth capital raise |
| 2022-10-25 | PowerUp Fall 2022 | Staff App merged with Member App, Appointments V2, Landing Pages V2 |
| 2023-01-01 | Sales Comp V1 + First Company-Wide Bonus | ARR / NPS / Check-ins as bonus metrics |
| 2023-10-01 | Appointments in Staff App | |
| 2024-01-16 | Product Sales in Staff App (Open Beta) | |
| 2024-03-01 | Sales culture shift | Focus on new logo growth; target 10k clients |
| 2024-07-09 | Core — Group Onboarding | |
| 2025-06-09 | Marketing moves under CEO | |
| 2025-06-23 | WOD Together shutting down | |
| 2025-07-07 | CrossFit Games; Reopening Free Funnel; Legacy MA Summit attendance | |
| 2025-07-21 | Won Alliance BJJ Co-Owner (3 + 3 coming); CrossFit APN agreement modified | |
| 2025-07-22 | Launched new Onboarding immersive experience | |
| 2025-07-28 | CX Support Pods formed | |
| 2025-08-25 | First Management Onsite | |
| 2025-09-08 | Pricing Workshop | |
| 2025-12-17 | Partners Marketplace shipped to 100% of clients | Major Core product milestone |

---

## Products

| Product | What It Is |
|---------|------------|
| **PP Core** | The main gym management platform: member billing, check-ins, scheduling, staff management, member app, communications. The system of record for a gym's operations. |
| **GymHappy** | Review and reputation management. Collects member reviews via SMS after class, displays them on a public Review Wall, and pushes 5-star reviews to Google. |
| **PushPress Grow** ("Grow") | Marketing and lead management CRM. Helps gyms capture, nurture, and convert prospects. Integrates with GoHighLevel (GHL/HL). |
| **Train** | Personal training / programming product. Launched 2022. |
| **Branded App** | White-label member app for gym owners ($97/month). Launched 2020. |

---

## Operating Tenets — The PushPress Way

### How We Think
- **Customer Obsessed** — Decisions start and end with customer impact.
- **Big Picture Thinkers** — Zoom out. Understand context and the "why" before acting.
- **Rationally Optimistic** — Expect things to work out; ground that optimism in evidence.
- **First Principle Problem Solvers** — Don't copy. Go back to first principles and reason from there.
- **Company-First Mindset** — Team over individual; company over team.

### How We Work
- **Urgency & Impact-Driven** — Move fast on the right things.
- **Take Ownership & Dig Deep** — Own outcomes, not just tasks.
- **High Standards of Excellence** — Don't ship mediocre. Raise the bar.
- **Embrace Adaptability & Agility** — The market changes; so should we.
- **Disagree & Commit** — Voice disagreement, then fully commit once decided.

### How Leaders Lead
- **Build & Elevate Best Teams** — Hire well; develop people.
- **Make Decisions & Own Outcomes** — Leaders don't wait for permission.
- **Foster Trust & Collaboration** — Psychological safety + high expectations.
- **Drive Clarity, Focus & Context** — Tell people the why, not just the what.
- **Elevate Ambitions** — Push the team to think bigger.
- **Solve Problems** — Remove blockers; don't create them.

---

## Long-Term Vision (3-Stage Strategy)

### AI-Native Philosophy
PushPress is architected from the ground up with AI at its core — not AI-enhanced, but AI-native. The product vision moves toward conversational interfaces and intelligent agents that run gym operations autonomously. The guiding principles:
- Human-first, AI-powered
- Default to leverage (AI amplifies human effort, doesn't replace it)
- Own the data flywheel (more data → better AI → better product → more gyms → more data)
- Prioritize network and data growth over short-term monetization
- Avoid distractions that don't compound the flywheel

### Stage 1 — System of Record (Present → 2026)
Become the undisputed operational standard for independent fitness businesses.
- AI-Native Core: intelligence embedded throughout the platform
- Pressly the Digital GM: an AI assistant that handles ops, answers questions, surfaces insights
- Product-Led Growth: the product sells itself
- Platform: open integrations, partner marketplace
- Mobile-first experience

### Stage 2 — Network Effects (through 2028)
Turn the platform into a network that creates value between gyms and between gyms and members.
- Syndicate Network: gyms connect and share
- Corporate Wellness: gyms sell to employers
- Crowdsourcing: collective intelligence from operator data
- Loyalty, Leads, Education, Retail, Advertising, Events, Benchmarking
- Member-facing features that create switching costs

### Stage 3 — Industry Ledger (2026–2028+)
Become the connective layer and data standard for the entire fitness industry.
- Data Normalization Engine: universal data model across fitness businesses
- Unified Consumer Fitness Profile: a member's fitness identity across gyms
- Predictive Industry Insights: benchmarks, forecasts, industry intelligence
- Medical Integration: fitness data meets health/wellness data
- Gym Valuation & Brokerage: PushPress data used to value and transact gym businesses

---

## Business Terms & Metrics

| Term | Meaning |
|------|---------|
| Logo | A single gym/customer account |
| Active Logo | A gym currently on a paid plan |
| ARR | Annual Recurring Revenue — annualized value of all active subscriptions. North star metric. |
| MRR | Monthly Recurring Revenue |
| GMV | Gross Merchandise Volume — total dollars processed through PushPress payments |
| GMV / Logo | Average GMV per active gym |
| Churn | Lost logos or lost ARR in a given period. Always in focus. |
| Retention | Opposite of churn — % of logos that stay |
| NPS | Net Promoter Score — customer satisfaction. Tracked as a bonus/comp metric. |
| New Logos | New gym customers added in a period |
| Martial Arts ARR/Logos | Tracked separately to measure progress on the MA/TAM initiative |
| TOFU | Top of Funnel — new leads and prospects entering the pipeline |
| Activation Rate | % of new gyms that fully set up and use the product |

---

## GymHappy-Specific Terms

| Term | Meaning |
|------|---------|
| GymHappy | PushPress's review management platform |
| HL / GHL | GoHighLevel — the CRM that GymHappy integrates with |
| Reviewer | A gym member who leaves a review via GymHappy |
| Coach | A gym staff member in GymHappy who can receive reviews |
| Review Wall | The public-facing page showing a gym's collected reviews |
| External Review | A GymHappy review shared to Google |
| DND | Do Not Disturb — flag to stop a member from receiving review request texts |
| Review Request | SMS sent to a gym member asking them to leave a review |
| Delay Window | How many minutes after class before a review request SMS is sent |
| Core Sync | Data syncing from PP Core to GymHappy/HL — check-ins trigger review requests |

---

## Teams

| Team | What They Do |
|------|-------------|
| Engineering | Builds and maintains all PushPress products |
| Product | Defines what gets built — roadmap, specs, research |
| Sales | Acquires new gym customers |
| CS / Customer Success | Onboards and retains gym customers |
| Support | Handles gym owner and member support tickets |
| Marketing | Brand, content, demand gen (moved under CEO in 2025) |
| Finance | Reporting, planning, accounting |
| Ops | Internal operations, HR, legal, admin |
| Leadership | Dan Uyemura (CEO), exec team |

---

## Tools & Systems

| Tool | Used For | Also Called |
|------|----------|-------------|
| Slack | Team communication | — |
| Notion | Docs, wikis, planning | — |
| Linear | Engineering issue tracking | — |
| Google Drive | Files and docs | Drive |
| Metabase | Business analytics / data warehouse | — |
| HighLevel / GHL | CRM (used in GymHappy context) | HL |
| Intercom | Customer support tickets | — |
| Stripe | Payments / billing | — |

---

## Key Internal Language

| Phrase | What It Means |
|--------|--------------|
| "the morning edition" | Daily briefing via Claude Cowork — metrics + Slack updates + leadership note |
| "WBR" | Weekly Business Review — Thursday metrics meeting |
| "in focus" | The current priority item (churn is almost always in focus) |
| "gym" / "logo" | A customer account (used interchangeably) |
| "the wall" | GymHappy review wall |
| "core sync" | Data syncing from PP Core to GymHappy/HL |
| "ship it" | Deploy to production |
| "on plan" | Meeting the business target (ARR, churn, etc.) |
| "missed plan" | Below target |
| "MA" or "TAM" | Martial Arts expansion initiative |
| "FF" | Functional Fitness segment |
| "TOFU" | Top of funnel |
| "Pressly" | The in-product AI Digital GM assistant |
