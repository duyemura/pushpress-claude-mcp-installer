# Cowork Tips of the Day
# ─────────────────────────────────────────────────────────────────────────────
# One tip surfaces each morning in the Morning Edition, rotating by day of week.
# Add new tips at the bottom — they'll cycle in automatically.
# Keep each tip short, specific, and immediately actionable.
# ─────────────────────────────────────────────────────────────────────────────

tips:

  - id: 1
    title: "Ask Claude to draft before you write"
    body: >
      Before you start typing any email, Slack message, or doc — ask Claude to
      draft it first. Even a rough draft you'll rewrite saves time and clears
      the blank-page paralysis. Try: *"Draft a quick Slack message to the team
      about [situation] — keep it under 4 sentences."*

  - id: 2
    title: "The more context you give, the better the output"
    body: >
      Claude doesn't know your history with a customer, your tone preferences,
      or what happened in yesterday's meeting — unless you tell it. Paste in
      background, share the email thread, or describe what you're trying to
      achieve. A 3-sentence setup often 10x's the quality of the response.

  - id: 3
    title: "Use /pp-install-mcp to connect your tools"
    body: >
      Need to connect GymHappy or Metabase? Run `/pp-install-mcp` and Claude
      will walk you through it in about a minute — finds the right API key,
      saves it securely, and confirms everything is working. No JSON editing
      required.

  - id: 4
    title: "Ask Claude to summarize a long Slack thread"
    body: >
      Got a 40-message thread you need to get up to speed on? Paste the thread
      (or just the channel ID + time range) and ask: *"Summarize the key
      decisions and open questions from this thread."* Works great for catching
      up after time off or a busy day of meetings.

  - id: 5
    title: "Claude can search across Slack for you"
    body: >
      Can't remember where that conversation happened? Try: *"Search Slack for
      any discussions about [topic] in the last two weeks."* Claude can search
      across channels and surface the most relevant threads — much faster than
      scrolling manually.

  - id: 6
    title: "Turn meeting notes into action items instantly"
    body: >
      After any meeting, paste your raw notes and ask: *"Extract the action
      items from these notes, who owns each one, and the due dates."* Claude
      will give you a clean list you can paste directly into Linear, Notion,
      or Slack.

  - id: 7
    title: "Use Claude to prep before a tough customer call"
    body: >
      Before a tricky support or success call, tell Claude the customer's
      situation and what you know about their account. Ask: *"What are the key
      things I should address, and what tone should I take?"* It's like having
      a quick pre-call huddle with a teammate who's read all the notes.

  - id: 8
    title: "Claude can look up any GymHappy account in seconds"
    body: >
      With GymHappy connected, you can ask things like: *"Look up [gym name]
      and tell me their setup status"* or *"Why isn't [email] getting review
      requests?"* Claude will pull the account, diagnose the issue, and often
      fix it in the same conversation.

  - id: 9
    title: "Ask for options, not just answers"
    body: >
      When you're stuck on a decision or approach, ask Claude for options
      rather than a single recommendation. *"Give me three different ways I
      could handle this situation"* — then pick the one that fits. You'll often
      see an angle you hadn't considered.

  - id: 10
    title: "Save your most-used prompts as Cowork commands"
    body: >
      If you find yourself asking Claude the same type of question every week,
      it's probably worth turning it into a custom command or skill. Ask Dan or
      mention it in #ai-tools — we can add it to the plugin so everyone
      benefits.

  - id: 11
    title: "Claude can write and iterate at the same time"
    body: >
      Don't try to write the perfect prompt first time. Start rough, then
      iterate: *"Make it shorter"*, *"More direct"*, *"Add a line about X"*,
      *"Change the tone to be warmer"*. It's faster to sculpt something Claude
      drafted than to start from scratch.

  - id: 12
    title: "Use /pp-morning-edition to start every day"
    body: >
      Run `/pp-morning-edition` first thing — it pulls company updates, key
      metrics, and a Cowork tip all in one place. Better yet, schedule it to
      run automatically at your start time so it's waiting when you open your
      laptop.

# ─────────────────────────────────────────────────────────────────────────────
# TO ADD A NEW TIP:
# Copy the block below and fill it in. The next available id number, a short
# title, and a 2-3 sentence body that's specific and actionable.
#
#   - id: 13
#     title: "Your tip title here"
#     body: >
#       Your tip content here. Keep it under 3 sentences and make it
#       immediately usable. Concrete examples help a lot.
# ─────────────────────────────────────────────────────────────────────────────
