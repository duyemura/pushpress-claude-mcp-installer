# PushPress Morning Edition — Config
# ─────────────────────────────────────────────────────────────────────────────
# This file controls what shows up in /pp-morning-edition every day.
# Edit any section and repackage the plugin to push updates to the team.
# ─────────────────────────────────────────────────────────────────────────────


## Slack Channels to Digest

List each channel that should be summarized in the morning brief.
Format: one channel name per line, with a short note on why it matters.

```
slack_channels:
  - channel: "#general"
    why: "Company-wide announcements and culture"

  - channel: "#company-announcements"
    why: "Official company-wide announcements from leadership"

  - channel: "#product"
    why: "What shipped, what's in progress, key decisions"

  - channel: "#engineering"
    why: "Technical updates, incidents, deploys"

  - channel: "#support"
    why: "Customer escalations and GymHappy issues"

  - channel: "#sales"
    why: "Pipeline updates, wins, and deal activity"

  - channel: "#unreasonable-moments"
    why: "Customer love stories and standout team moments — culture pulse"

  - channel: "#customer-love"
    why: "Positive customer feedback, reviews, and wins worth celebrating"

  # ADD MORE CHANNELS HERE — copy the format above
  # - channel: "#marketing"
  #   why: "Campaign and content updates"
```


## CEO Message Source

Where Dan posts his daily message for the team.
The morning brief will check here first and surface it prominently.

Uncomment ONE option and fill it in:

```
# Option A: A dedicated Slack channel Dan posts in
ceo_message_source:
  type: slack_channel
  channel: "#morning-edition"   # ← change this to the real channel

# Option B: A Notion page Dan edits directly
# ceo_message_source:
#   type: notion_url
#   url: "https://www.notion.so/YOUR-PAGE-ID-HERE"
```


## Metrics Snapshot Source

Where the brief pulls PushPress business metrics from.

Recommended: set up a separate daily scheduled task (Dan only) that pulls
from Metabase and writes to a Notion page — then point this config at that
Notion page. This way everyone gets metrics without needing Metabase access.

Uncomment ONE option:

```
# Option A: Pre-pulled Notion page (recommended for team-wide use)
# metrics_source:
#   type: notion_url
#   url: "https://www.notion.so/315233ce1c1781c9a8c3e4b3891b3c5c"
#   # This page is updated daily at 1:30 AM by the pp-daily-metrics-snapshot scheduled task.
#   # The scheduled task pulls from Metabase and writes formatted WBR metrics here.
#   # NOTE: Currently returns 401 — pp-daily-metrics-snapshot needs Metabase API key configured.

# Option B: Pull live from Metabase (requires Metabase to be connected)
metrics_source:
  type: metabase
  dashboard_url: "https://pushpress.metabaseapp.com/dashboard/6668-daily-flash-dashboard?tab=7097-net-new-saas-mrr"
  # Cached card IDs — discovered 2026-03-01. Use these directly to skip expensive search/discovery.
  # IMPORTANT: Execute these IDs directly with execute_card(id) — do NOT search for cards by name.
  metric_card_ids:
    churn:
      - id: 21121   # Today's Churn Volume (count)
      - id: 21122   # Today's Churn MRR ($)
      - id: 21127   # MTD Churn Volume (count)
      - id: 21128   # MTD Churn MRR ($)
      - id: 21125   # Monthly Churn Forecast Attainment (vs plan %)
    net_new_mrr:
      - id: 21144   # MTD Net New SaaS MRR
      - id: 21145   # MTD MRR Addition
      - id: 21148   # QTD Net New MRR
    arr:
      - id: 11729   # SaaS ARR — MTD current value
      - id: 6215    # WBR ARR by Week (trend)
    logos:
      - id: 15643   # WBR Total Monetized Activated Logos
      - id: 15742   # WBR Total Monetized Logos by Day vs Week
    martial_arts:
      - id: 18020   # MA Booked MRR per Week
      - id: 21326   # MA Booked MRR per Day
```


## WBR / OKR Metrics Structure

The metrics snapshot is organized around four categories that match the
PushPress Weekly Business Review (WBR) and OKR tracking format.

Claude should look for these metrics in Metabase and display them in this order.
If a metric isn't available, skip it rather than showing a blank.

```
wbr_metrics:

  - category: "Customer Value"
    metrics:
      - name: "NPS"
        description: "Net Promoter Score"
      - name: "GMV"
        description: "Gross Merchandise Value processed through PushPress"
      - name: "GMV Per Active Logo"
        description: "GMV divided by active gym count"

  - category: "Company Value"
    metrics:
      - name: "ARR"
        description: "Annual Recurring Revenue"
        show_growth: true   # show WoW, MoM, YoY delta
      - name: "Logos"
        description: "Active gym accounts"
        show_growth: true
      - name: "Growth"
        description: "Overall growth rate"
        periods: ["WoW", "MoM", "YoY"]

  - category: "Martial Arts (TAM Initiative)"
    description: "New vertical expansion — track separately to gauge traction"
    metrics:
      - name: "ARR"
        show_growth: true
      - name: "Logos"
        show_growth: true
      - name: "Growth"
        periods: ["WoW", "MoM", "YoY"]

  - category: "IN FOCUS: Churn"
    description: "Current OKR focus area — Grow (reduce) Churn"
    highlight: true   # always show prominently, even if other sections are skipped
    metrics:
      - name: "Churn This Week"
      - name: "Churn This Month"
      - name: "vs Last Month"
        description: "Month-over-month churn comparison"
      - name: "vs Plan"
        description: "Actual churn vs plan/target"
```


## Standing PushPress Context

This text is included as background context for every morning brief.
Update it whenever company priorities shift. Claude uses this to frame
the brief and keep the team oriented around what matters most right now.

```
pushpress_context: |
  PushPress is the operating system for gym businesses. We serve independent
  gym owners with software for memberships, billing, scheduling, and marketing.
  GymHappy is our review and reputation product.

  Current focus areas (Q1 2026):
  - Reducing churn — current OKR "IN FOCUS" priority
  - Expanding into Martial Arts as a new vertical (TAM initiative)
  - Growing GymHappy attach rate and active review volume
  - Improving NPS and customer GMV per logo

  Key metrics we care about daily:
  - Active gym logos and ARR (overall + Martial Arts segment)
  - Churn (vs plan, WoW, MoM)
  - GMV and GMV per active logo
  - NPS
  - GymHappy reviews generated per week
  - Support ticket open rate
```


## Tone & Format Preferences

```
tone: "Direct, energetic, team-first. Like a great standup, not a board report."
length: "Scannable in under 2 minutes. Bullets over paragraphs."
emoji: true
```


# ─────────────────────────────────────────────────────────────────────────────
# HOW TO UPDATE THIS CONFIG
# ─────────────────────────────────────────────────────────────────────────────
# 1. Edit this file in any text editor
# 2. Ask Claude: "Repackage the pushpress-team plugin"
# 3. Share the new .plugin file with the team
# 4. They reinstall — takes 30 seconds
# ─────────────────────────────────────────────────────────────────────────────
