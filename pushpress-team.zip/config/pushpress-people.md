# PushPress People & Org Chart

> Last updated: February 2026. Sources: PushPress internal Notion (Team Directory, Leadership Business Review meeting notes, Slack). Names and roles sourced from August 2025 leadership review attendance records. This file is a living document — update when org changes occur.

---

## Executive Team

| Name | Role | Notes |
|---|---|---|
| **Dan Uyemura** | CEO / Co-Founder | Company vision, culture, overall direction. Slack handle: @dan |
| **Nick Reyes** | CRO (Revenue) | Owns all revenue: Sales, Marketing/Growth, RevOps |
| **Brian Aung** | CFO / COO (Finance & Operations) | Finance, People Ops, and operational functions |
| **Arjun Shah** | CTO / VP R&D | Engineering, Product, Design |

---

## Department Map

```
PushPress
├── Revenue (Nick Reyes)
│   ├── Sales (John Batdorff)
│   │   ├── Sales Development (SDR team)
│   │   └── Account Executives
│   ├── Revenue Operations (Ian Chand)
│   └── Growth / Marketing (Melissa Chuang)
│
├── R&D (Arjun Shah)
│   ├── Engineering
│   ├── Product (Chris McConachie)
│   ├── Design
│   └── Product Implementation
│
├── Customer Experience / CX (Barry Pepper)
│   ├── CX Success (Gavin Danfelt-Martin)
│   ├── CX Advocacy / Onboarding (Jessica Hamel)
│   └── CX Operations (James Plata)
│
├── Finance (Brian Aung)
│   ├── Norman Lee
│   └── Rocky Yip
│
└── People Operations / POPs (Brian Aung → Ali Cadmus)
```

---

## Team Directory

### Executive
- **Dan Uyemura** — CEO
- **Nick Reyes** — CRO
- **Brian Aung** — CFO / COO
- **Arjun Shah** — CTO

### Sales
- **John Batdorff** — Sales Lead / Director
- **Shannon Sofield** — Sales
- **David Walczak** — Sales

### Sales Development (SDR)
- Managed under Sales org

### Revenue Operations
- **Ian Chand** — RevOps Lead
- **Jeremy Farbota** — Analytics / Data

### Growth / Marketing
- **Melissa Chuang** — Growth Lead
- **Nolan Parker** — Growth

### R&D — Product
- **Chris McConachie** — Product Lead
- **Marissa Paulsen** — Product (role TBC)

### R&D — Engineering
- (Engineering team under Arjun Shah — individual ICs not captured here)

### R&D — Design
- (Design team under Arjun Shah)

### R&D — Product Implementation
- (Handles rollout and enablement of new product features)

### Customer Experience (CX)
- **Barry Pepper** — CX Director / Lead
- **Gavin Danfelt-Martin** — CX Success
- **Dave Yandel** — CX / Grow team
- **Shad Lorenz** — CX Support

### CX — Onboarding / Advocacy
- **Jessica Hamel** — CX Advocacy & Onboarding Lead
- **Patrick Chandler** — CX Onboarding
- **Neil Shaffer** — CX Onboarding
- **Paul Markhauser** — CX Onboarding

### CX — Operations
- **James Plata** — CX Operations Lead

### Finance
- **Norman Lee** — Finance
- **Rocky Yip** — Finance

### People Operations (POPs)
- **Ali Cadmus** — People Operations Lead

---

## Key Cross-Functional Notes

**Revenue org structure:** Nick Reyes runs Sales, Growth, and RevOps as a unified revenue function. John Batdorff leads the sales team day-to-day. Ian Chand owns the RevOps systems and data infrastructure.

**Product org:** Arjun Shah owns all of R&D. Chris McConachie leads Product. Engineering, Design, and Product Implementation all report into this org.

**CX structure:** Barry Pepper leads CX overall. The team has three distinct sub-functions: Success (retention, health), Onboarding/Advocacy (new gym setup and champions), and Operations (process and tooling).

**People + Finance under Brian Aung:** Unusual but intentional — Brian owns both the financial and human capital functions as COO/CFO.

---

## Internal Communication Conventions

- Most cross-team communication happens in **Slack**.
- Executive syncs and leadership reviews happen in **Notion** (Leadership Business Review is the key recurring leadership forum).
- Dan goes by **@dan** in Slack (not @danuyemura).
- The company is small enough that most people know each other — use first names freely.

---

## Tips When Referencing People

- If you're unsure of someone's exact role, default to their department (e.g., "someone on the CX team").
- Leadership Business Reviews include department heads + key leads — that's the core leadership layer below the exec team.
- For anything People Ops (hiring, HR, benefits), contact **Ali Cadmus**.
- For anything Finance/billing, contact **Norman Lee** or **Rocky Yip**.
- For anything product-related from a customer perspective, **Chris McConachie** is the product lead.
