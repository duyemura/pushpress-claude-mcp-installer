# PushPress Company Context

Pre-seeded knowledge for every PushPress team member. Loaded into `memory/context/pushpress.md` during onboarding.

---

## What PushPress Does

PushPress is a gym management platform — software that helps fitness businesses (CrossFit gyms, martial arts schools, boutique fitness studios) run their operations: member check-ins, billing, scheduling, staff management, and communications.

**Key products:**
- **PP Core** — the main gym management platform (billing, check-ins, scheduling, member management)
- **GymHappy** — review and reputation management for gym owners (collects member reviews, pushes to Google)
- **PushPress Grow** (sometimes called "Grow") — marketing and lead management tools

---

## The Business

| Term | Meaning |
|------|---------|
| Logo | A single gym/customer account |
| Active Logo | A gym currently on a paid plan |
| ARR | Annual Recurring Revenue — the annualized value of all active subscriptions |
| MRR | Monthly Recurring Revenue |
| GMV | Gross Merchandise Volume — total dollars processed through PushPress payments |
| GMV / Logo | Average GMV per active gym |
| Churn | Lost logos or lost ARR in a given period |
| Retention | Opposite of churn — % of logos that stay |
| NPS | Net Promoter Score — member/customer satisfaction metric |

---

## Strategic Initiatives

| Initiative | What It Is |
|------------|-----------|
| Martial Arts / TAM | Expansion into martial arts gyms (Brazilian Jiu-Jitsu, MMA, Muay Thai, Karate, etc.) — a major growth initiative |
| TAM | Total Addressable Market; often shorthand for the Martial Arts initiative |
| WBR | Weekly Business Review — the weekly metrics/performance meeting |

---

## GymHappy-Specific Terms

| Term | Meaning |
|------|---------|
| GymHappy | PushPress's review management platform |
| HL / GHL | GoHighLevel — the CRM that GymHappy integrates with |
| Reviewer | A gym member who leaves a review via GymHappy |
| Coach | A gym staff member in GymHappy who can receive reviews |
| Review Wall | The public-facing page showing a gym's collected reviews |
| External Review | A GymHappy review that was shared to Google |
| DND | Do Not Disturb — flag to stop a member from receiving review request texts |
| Review Request | SMS sent to a gym member asking them to leave a review |
| Delay Window | How many minutes after a class before a review request is sent |
| PP Core | The PushPress core platform (check-ins from here trigger review requests in GymHappy) |

---

## Teams

| Team | What They Do |
|------|-------------|
| Engineering | Builds and maintains all PushPress products |
| Product | Defines what gets built — roadmap, specs, research |
| Sales | Acquires new gym customers |
| CS / Customer Success | Onboards and retains gym customers |
| Support | Handles gym owner and member support tickets |
| Marketing | Brand, content, demand gen |
| Finance | Reporting, planning, accounting |
| Ops | Internal operations, HR, legal, admin |
| Leadership | Dan (CEO), exec team |

---

## Tools & Systems

| Tool | Used For | Also Called |
|------|----------|-------------|
| Slack | Team communication | — |
| Notion | Docs, wikis, planning | — |
| Linear | Engineering issue tracking | — |
| Google Drive | Files and docs | Drive |
| Metabase | Business analytics / data warehouse | — |
| HighLevel / GHL | CRM (used in GymHappy context) | HL |
| Intercom | Customer support tickets | — |
| Stripe | Payments / billing | — |

---

## Key Internal Language

| Phrase | What It Means |
|--------|---------------|
| "the morning edition" | Daily briefing via Claude Cowork — metrics + Slack updates + leadership note |
| "WBR" | Weekly Business Review — Thursday metrics meeting |
| "in focus" | The current priority item (churn is almost always in focus) |
| "gym" | A customer / logo (used interchangeably with "gym" and "logo") |
| "the wall" | GymHappy review wall |
| "core sync" | Data syncing from PP Core to GymHappy/HL |
| "ship it" | Deploy to production |
| "on plan" | Meeting the business target (ARR, churn, etc.) |
| "missed plan" | Below target |

---

## Key Metrics & Their Context

| Metric | Why It Matters |
|--------|----------------|
| ARR | North star — total business health |
| Churn | Always a focus; losing logos or ARR is a top concern |
| GMV | Shows how much financial activity is running through PP (proxy for gym health) |
| NPS | Measures member satisfaction — leading indicator of retention |
| New Logos | New gym customers added in a period |
| Martial Arts ARR/Logos | Tracked separately to measure progress on the TAM initiative |
