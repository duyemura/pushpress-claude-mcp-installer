# PushPress Competitor Battle Cards

> Last updated: February 2026. Sources: PushPress internal Notion battle cards, sales team intel.

---

## How to Use This File

Each section covers a competitor with: quick summary, how to spot them, why we win, why we lose, pricing intel, and quick-dismiss notes. Use this when preparing for a sales call, handling an objection, or researching a prospect's current software.

---

## Wodify

**Overview:** Founded 2012, ~77 employees, ~$11M revenue. One of the oldest gym management platforms; historically strong with CrossFit boxes. They use a sub-merchant payment processing model (unlike PP's direct Stripe relationship).

**Why We Win**
- **Payments:** PP merchants own their Stripe account directly — funds settle in 1-2 business days. Wodify uses a sub-account model where payouts take 2-14 days and owners can't control their own payment account.
- **Simplicity:** Wodify requires ~8 clicks to complete tasks that PP does in 1.
- **Support:** PushPress offers live chat. Wodify is email-only.
- **CRM:** PP has a built-in CRM; Wodify does not (or requires add-ons).

**Why We Lose**
- No Coach Board / kiosk mode in PushPress (Wodify has one).
- PP passes processing fees to members (can be a friction point); Wodify absorbs or structures differently.
- Multi-location with fluid membership (members moving between locations) — Wodify handles this better.

**Pricing**
- Engage: $99/mo
- Grow: $199/mo
- Promote: $299/mo
- Plus processing fees on top.

---

## MindBody

**Overview:** The largest player in the wellness/fitness space — serves yoga, Pilates, salons, spas, and gyms. Enterprise-scale and feature-rich but expensive and bloated for functional fitness gyms.

**Why We Win**
- Processing rates are very high (4-5%) — PP is significantly cheaper on processing.
- UI is outdated and clunky.
- No native waivers.
- No sub-accounts for multi-location.
- No native CRM.
- No workout tracking.
- Frequent price increases with no added value for the gym.

**Why We Lose**
- Pure breadth of functionality — they serve every type of wellness business.
- Better multi-location support.
- The MindBody marketplace (consumer-facing app) drives leads directly to gyms.

**Quick Dismiss**
Not the right tool for functional fitness or CrossFit gyms. They're built for appointment-based businesses. If a prospect is on MindBody, it likely means they haven't found a platform built for their community.

---

## Glofox

**Overview:** Irish-founded, now US-focused. Known for aggressive sales tactics and long-term contracts. Tends to target boutique fitness studios.

**Why We Win**
- PP processing rates are more competitive.
- PP doesn't require contracts — Glofox does.
- PP is a more trusted partner with a track record in the CrossFit/functional fitness community.

**Why We Lose**
- Glofox has a slicker consumer-facing app and studio experience.
- Stronger in pure boutique fitness (cycling, yoga, Pilates) where community features matter less.

**Quick Dismiss**
Lead with "no contracts, ever" as a value prop. Glofox locks gyms in — PP never does.

---

## ZenPlanner

**Overview:** One of the OG gym management platforms. Long-standing in the CrossFit community. Owned by Active Network / Daxko. Known for being complex and outdated.

**Why We Win**
- Simpler UX — ZenPlanner is notoriously complex to navigate.
- Better price point for what you get.
- All-in-one app: PP Core + PP Train in one ecosystem. ZenPlanner requires ZP + SugarWOD (a separate app) to get workout tracking.
- Better client (member) experience — ZenPlanner's member-facing app is dated.
- No branded app option in ZenPlanner.
- Financials reporting is convoluted in ZP.

**Why We Lose**
- ZenPlanner offers ACH payments at 0% + $0.30 (very cheap) — this is a real objection.
- Better multi-location support.
- Hybrid memberships — ZP allows more complex/custom membership structures.
- Custom contracts and memberships.

**Key Objection to Prep**
ACH pricing: ZP's 0% ACH is a legitimate advantage. Counter with the overall lower processing rates PP offers and the value of owning your Stripe account.

---

## Wellness Living

**Overview:** A Canadian-founded platform targeting general fitness and wellness businesses. Often selected for price. Limited intel in our system.

**Why We Win**
- Lower price point than WL for what you get.
- Better processing rates.

**Why We Lose**
- Wellness Living supports recurring class booking — PP does not (members can book a recurring spot in a weekly class). This is a real feature gap.

**Quick Note**
Limited competitive intel on this one. If you encounter a prospect on Wellness Living, use general PP value props: community features, Stripe ownership, no contracts, support quality.

---

## Chalk it Pro / BLG (Black Label Gym)

**Overview:** Two related/adjacent competitors targeting small boutique/lifestyle gyms. Chalk it Pro is a newer platform built by a developer who is himself a gym member. BLG (Black Label Gym) appears to be a single-page site with no SEO presence.

**How to Spot Them**
- Chalk it Pro gyms typically have a **black background** in their member app — easy visual identifier.

**Quick Dismiss**
- BLG: One-page website, no SEO indexing, minimal product substance.
- Chalk it Pro: Developer is a gym member (not a dedicated software company), no dedicated staff app.

**Why We Win**
- PP has a full staff app.
- PP has a full product team and roadmap.
- PP has established support infrastructure.
- PP has been around longer with a proven track record.

**Why We Lose**
- Price — Chalk it Pro is aggressively priced (currently offering free access to anyone switching to BLG).
- Mentoring/coaching model — BLG may bundle business coaching with software, which is appealing to some gym owners.

**Current Promo to Be Aware Of**
Chalk it Pro is currently offering free access to gyms that switch to BLG. This is a bait-and-switch to watch for.

---

## Kilo (formerly Gym Lead Machine / GLM)

**Overview:** The most important competitor to understand right now. Kilo was rebranded from Gym Lead Machine (GLM) and is backed by **Chris Cooper** of **Two Brain Business** — the largest gym business coaching community. It's built on top of Go High Level (GHL) and targets the coaching-centric gym owner.

**Why This Matters**
Two Brain Business has massive mindshare with gym owners who invest in business education. If a prospect is a Two Brain client, they'll hear about Kilo constantly. Understanding this ecosystem is critical.

**Kilo's Pricing (the "Kilo Stack")**
| Product | Price |
|---|---|
| Website | $29/week (~$126/mo) |
| GLM (CRM/lead management) | $82/week (~$355/mo) |
| The Kilo Stack (full bundle) | $139/week (~$602/mo) |
| Core / Member Management | $150/mo + 2.89% + $0.30/txn |

**Critical:** Kilo requires a **52-week commitment** with cancellation fees. This is a major differentiator for PP.

**Why We Win vs. Kilo**
- **No contracts, ever.** Kilo locks gyms in for a full year with cancellation penalties.
- **Cost:** Despite Two Brain's positioning, Kilo is roughly **$50+/month more expensive** than PP when you add it up.
- **Staff App:** Kilo has no staff app — browser only. PP has a full staff app.
- **Gamification:** PP has built-in gamification; Kilo does not.
- **Workout Tracking:** PP (via PP Train) has workout tracking; Kilo does not.
- **Kiosk Mode:** PP has a kiosk/check-in mode; Kilo does not.
- **Batch Billing:** PP supports batch billing; Kilo does not.
- **Fee Pass-Through:** PP does fee pass-through; Kilo does not.
- **Social Feed:** PP has a social/community feed; Kilo does not.
- **Uptime:** Kilo has **scheduled downtime during business hours** — PP does not.
- **SMS Volume:** PP provides 2,500 SMS/month; Kilo provides only 1,200.
- **Data Sync:** Kilo (Gym Lead Machine) does not yet sync GLM contact data with their GMS (gym management side) — so owner is managing two separate data sets.

**Why We Lose / Their Pitch**
- Two Brain endorsement carries weight — gym owners who trust Chris Cooper trust Kilo.
- Kilo offers a steep discount for the first 3 months to get gyms in the door.
- The 52-week contract creates artificial commitment that keeps gyms from leaving even if unhappy.
- Full marketing/website/CRM bundle is appealing to gym owners who want one vendor for everything.

**Suggested Positioning vs. Kilo**
Lead with: no contracts + lower total cost + staff app + workout tracking + no scheduled downtime. If they're a Two Brain client, acknowledge the relationship but point out that Kilo's value comes from the coaching, not the software — and PP is the better software.

---

## General Competitor Positioning Notes

**Our unfair advantages that cut across all competitors:**
1. **Stripe ownership** — most competitors use sub-merchant models. PP gym owners own their payment account.
2. **No contracts** — ever. This is a true differentiator vs. Glofox, Kilo, and others.
3. **PP Core + PP Train** as an integrated stack — no need to buy SugarWOD separately.
4. **GymHappy integration** — automated review collection built into the ecosystem.
5. **Live chat support** — most competitors offer email-only or ticketing.
6. **Community** — PP has deep roots in functional fitness; we know this customer.

**Common objections and quick counters:**
- *"ZenPlanner has cheaper ACH"* → True, but factor in total cost of ownership and the complexity tax your staff pays every day.
- *"Kilo includes a website and CRM"* → At $600+/mo locked into a 52-week contract. PP + a $30/mo website is still cheaper, with no lock-in.
- *"MindBody has more features"* → Built for spas and yoga studios, not functional fitness communities. You'd pay for 80% you'll never use.
- *"We're considering Glofox"* → Ask if they've seen the contract terms. PP has never required a contract.
