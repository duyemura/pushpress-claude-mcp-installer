# PushPress Ideal Customer Profile (ICP)
<!-- Pre-seeded into context for sales, marketing, and growth work -->
<!-- Last updated: 2026-02-28 — Sources: Notion (ICP v1 4.22.25, Clay 2026 ICP Agent Lead Quality Model, RevOps Firmographics, User Personas: ICP Expansion) -->

---

## ICP Definitions by Segment

| Segment | Definition |
|---------|------------|
| **Freemium ICP** | A current or soon-to-launch gym offering coach-led group and personal training, making **less than $8,000/month**. |
| **Paid ICP** | A CrossFit-style US-based gym delivering coach-led group and personal training, making **$8,000+/month**. |
| **Emerging Paid ICP** | A US-based martial arts academy delivering coach-led group and personal training, making **$8,000+/month**. |

---

## 2026 ICP Tier Framework (Lead Quality Model)

| Tier | Score | Label | Description |
|------|-------|-------|-------------|
| **Tier 1** | 8–10 | True ICP Fit | Coach-led, group-based gyms with recurring memberships, strong community identity, and multi-program offerings. |
| **Tier 2** | 5–7 | Emerging ICP | Coach-led training businesses with class-based delivery and recurring revenue, but differing cultural or operational norms. |
| **Tier 3** | 1–4 | Non-ICP | Fitness or wellness businesses that do not align with PushPress's core value proposition. |

---

## Tier 1 — Primary ICP Gym Types

| Category | Sub-Types |
|----------|-----------|
| **Functional Fitness** | CrossFit, Circuit Training, Bootcamp, Kettlebell, Olympic Lifting, Strength & Conditioning |
| **Strength** | Weightlifting, Powerlifting |
| **Group Fitness** | Coach-led group classes with recurring memberships |
| **Sports Specific Training** | Sports performance, athlete development |

---

## Tier 2 — Emerging ICP (Martial Arts / Combat Sports)

Primary focus: **Brazilian Jiu-Jitsu (BJJ)**. Also includes: Boxing, Kickboxing, Muay Thai, Taekwondo, Karate, MMA. These gyms share the coach-led, community-driven model but have different operational patterns (belt tracking, class types, etc.).

---

## Tier 3 — Non-ICP (Do Not Target)

Yoga, Pilates, Barre, Spin/Cycling, Zumba/Dance, Mind-Body studios, Outdoor fitness, 24/7 Health Clubs, Bodybuilding-only, Personal Training-only (no group), Rehab/Senior fitness.

---

## All-Time Customer Data by Gym Type

| Gym Type | All-Time Logos |
|----------|---------------|
| Functional Fitness | 9,706 |
| Personal Training | 2,815 |
| Other / Combination | 2,624 |
| Martial Arts | 2,566 |
| Health Club | 1,379 |
| Studio Fitness | 946 |
| Training Gym | 783 |

**Top sub-types:**

| Sub-Type | All-Time Logos |
|----------|---------------|
| CrossFit | 4,458 |
| Strength and Conditioning | 3,285 |
| Small Group Personal Training | 2,810 |
| Combat Sports | 1,345 |
| Indoor Bootcamp | 1,139 |

---

## ICP Scoring Dimensions (RevOps Methodology)

The 2026 lead scoring model evaluates prospects across four dimensions:

1. **ICP Fit** — Does the gym type, model, and coaching style match Tier 1 or Tier 2?
2. **Data Confidence** — How reliable and complete is the firmographic data?
3. **Commercial Readiness** — Is the gym at a stage where they're likely to buy?
4. **Value & Scale Potential** — GMV potential, member count, growth trajectory?

---

## Future ICP Expansion Criteria

New segments will be considered for ICP status based on: close rates, NPS, CSAT, churn rates, and international performance data.
