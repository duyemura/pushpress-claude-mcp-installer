# PushPress Strategy & OKRs
<!-- Pre-seeded into context for planning, roadmap, and strategy work -->
<!-- Last updated: 2026-02-28 — Sources: Notion (Company OKRs, Q1 2026 Roadmap Planning, Strategic Vision) -->

---

## Current OKRs — Q1 2026

**North Star Metric:** Paid Logo Growth

**Q1'26 Company Goals:**
1. Improve Customer Sentiment
2. Supercharge Martial Arts
3. Grow Functional Fitness

**OKR 1 — Drive & Unblock Overall TOFU**
*Output:* Q1'26 New Core SaaS MRR Booked
Top of funnel — more gyms entering the pipeline.

**OKR 2 — Delightful Core Onboarding**
*Output:* Q1'26 Cohort Activation Rate
Getting new gyms to fully activate faster. Target: 40%+ creating a plan on Day 1 (up from 21%).

**OKR 3 — Ensure Grow Customers Realize Value**
*Output:* Q1'26 Cohort Grow Retention and Overall Grow Churn
Making sure gyms using Grow actually succeed with it.

**OKR 4 — Artificial Intelligence**
*Outputs:*
- 50% of Core Pro gyms use AI Assistant weekly
- GrowAI Website Launch

*2025 archived NSM for reference:* Logo Count; Goal was 6,000 Core Logos.

---

## 2026 Annual Plan

### Strategic Shift
2026 marks a pivot from **retention-focused growth to acquisition-led growth**. The operating principle: go deeper, not wider. Three pillars anchor everything — **AI**, **Growth Systems**, and **Martial Arts**.

### Growth Targets
- **3,200 net new logos** — 70–75% YoY growth
- **Minimum $55k net new MRR monthly**

| Segment | Target Logos |
|---------|-------------|
| CrossFit / Strength & Conditioning (ICP) | 1,900 |
| Martial Arts (4x increase) | 800 |
| Personal Training / Non-ICP | 500 |

### Acquisition Channel Mix

| Channel | Logo Target |
|---------|------------|
| Paid Search & Ads | 1,700 |
| Partnerships (newly formalized) | 600 |
| Outbound Sales | 500 |
| Events | 300–400 |
| Funnel Experiments | 100 |

### Funnel Strategy
H1 focus: **open the free funnel** to drive top-of-funnel volume. H2 follow-through: raise prices in Q2/Q3 as NPS improves.

**Demand gen targets:**
- 230 Martial Arts demos
- 809 free funnel demos

### Onboarding & Activation Targets (Q1)

| Milestone | Target |
|-----------|--------|
| Belt tracking completion (MA) | 50% → 75% |
| Create a plan on Day 1 | 40%+ (up from 21%) |
| Connect Stripe within 1 week | 50% |
| Use migration assistant within 30 days | 30% |
| First member purchase within 1 week | 40% |
| Website launched by go-live date | 70% |
| First GymHappy review within 15 days | 70% |

### AI Pillar
PushPress is positioning as the **first native AI-powered platform for gyms and academies** — AI integrated as a team member, not a bolt-on. Competitors' AI offerings are lightweight reporting copilots; PushPress is building a system of actions.

**Target outcome:** Lift median gym revenue by **$10k/month**.

**Q1 AI releases:** AI Assistant, Unified Inbox, Class Prep Tools, GrowAI Alpha

**AI OKR targets:**
- 50% of Core Pro gyms using AI Assistant weekly
- 50% week-over-week retention on AI features
- GrowAI Website Alpha launch

### Go-to-Market Priorities
- Refresh positioning and messaging
- Establish internal and external roadmaps
- Define beta-to-GA process
- Coordinate cross-channel tactics (paid, events, partnerships, outbound)

---

## Strategic Initiatives (Current Focus)

| Initiative | What It Is |
|------------|------------|
| **Martial Arts / TAM** | Expansion into martial arts gyms (Brazilian Jiu-Jitsu, MMA, Muay Thai, Karate, etc.) — major growth initiative. Often called "MA" or "TAM" (Total Addressable Market shorthand). |
| **Functional Fitness (FF)** | CrossFit and functional fitness segment — original core market, now being grown further. |
| **AI Assistant / Pressly** | In-product AI for gym operators. Near-term OKR: 50% of Core Pro gyms using weekly. |
| **GrowAI** | AI features in the Grow product, starting with AI website generation. |
| **Freemium / Free Funnel** | Product-led growth lever — free tier drives top-of-funnel. Reopened in 2025. |
| **Partner Marketplace** | Third-party integrations shipped to 100% of clients in Dec 2025. |
