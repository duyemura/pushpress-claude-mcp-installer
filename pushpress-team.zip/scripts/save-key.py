#!/usr/bin/env python3
"""
save-key.py — Securely save an API key or URL to ~/.claude/settings.json

Usage: python3 save-key.py KEY_NAME KEY_VALUE

Keys are stored in the `env` section of ~/.claude/settings.json, which
Claude loads at startup. Existing settings are preserved.
"""

import json
import os
import sys


def _settings_path() -> str:
    """
    In the Cowork VM, the Mac's actual ~/.claude/ is mounted at
    /sessions/<id>/mnt/.claude/ — not at ~/. We detect this by checking
    for the mnt/.claude directory relative to HOME, and prefer it when found.
    """
    vm_home = os.environ.get("HOME", "/root")
    mnt_path = os.path.join(vm_home, "mnt", ".claude", "settings.json")
    if os.path.isdir(os.path.dirname(mnt_path)):
        return mnt_path
    # Fallback for non-Cowork environments (Claude Code on Mac, etc.)
    return os.path.expanduser("~/.claude/settings.json")


def save_key(key_name: str, key_value: str) -> None:
    settings_path = _settings_path()

    # Load existing settings or start fresh
    if os.path.exists(settings_path):
        with open(settings_path, "r") as f:
            try:
                settings = json.load(f)
            except json.JSONDecodeError:
                settings = {}
    else:
        settings = {}

    # Ensure env section exists
    if "env" not in settings:
        settings["env"] = {}

    # Set the key
    settings["env"][key_name] = key_value

    # Write back atomically (write to temp, then rename)
    tmp_path = settings_path + ".tmp"
    with open(tmp_path, "w") as f:
        json.dump(settings, f, indent=2)
        f.write("\n")
    os.replace(tmp_path, settings_path)

    # Confirm without echoing the full value
    masked = ("****" + key_value[-4:]) if len(key_value) > 4 else "****"
    print(f"✅  {key_name} saved to ~/.claude/settings.json ({masked})")
    print("   Restart Claude / Cowork for the new key to take effect.")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 save-key.py KEY_NAME KEY_VALUE", file=sys.stderr)
        sys.exit(1)

    key_name = sys.argv[1].strip()
    key_value = sys.argv[2].strip()

    if not key_name:
        print("Error: KEY_NAME cannot be empty", file=sys.stderr)
        sys.exit(1)

    if not key_value:
        print("Error: KEY_VALUE cannot be empty", file=sys.stderr)
        sys.exit(1)

    save_key(key_name, key_value)
