# PushPress Team Plugin

This plugin provides GymHappy support tools, Metabase analytics, and team onboarding for the PushPress team.

## Required API Keys

This plugin needs up to three API keys to function:

| Key | Purpose | Required? |
|-----|---------|-----------|
| `GYMHAPPY_MCP_TOKEN` | GymHappy support tools (lookup gyms, reviewers, messages, etc.) | For GymHappy work |
| `METABASE_URL` | Metabase instance URL | For data/analytics work |
| `METABASE_API_KEY` | Metabase API access | For data/analytics work |
| `GITHUB_APP_PRIVATE_KEY` | GitHub App private key (read-only access to PushPress repos) | For /pp-bug-check |

## Session Start Check

At the start of every session, run two checks: (1) credentials, and (2) whether the user has a profile set up.

### Check 1: Credentials

Check which credentials are missing by reading the settings file:

```bash
cat ~/mnt/.claude/settings.json 2>/dev/null || echo "{}"
```

Look at the `env` object in the JSON output. Check for these keys:
- `GYMHAPPY_MCP_TOKEN` — needed for GymHappy MCP
- `METABASE_API_KEY` — needed for Metabase MCP
- `GITHUB_APP_PRIVATE_KEY` — needed for GitHub MCP (used by /pp-bug-check)

If either key is missing or empty, that MCP isn't connected yet.

**If any keys are missing**, mention it naturally at the start of the session — something like:

> "Hey! I notice you don't have [KEY_NAME] set up yet. Run `/pp-install-mcp` and I'll walk you through it — takes about a minute."

Only mention this **once per session**. Don't nag. If the user dismisses it or says they'll do it later, drop it.

If all keys are present, no need to mention anything — just proceed normally.

### Check 2: User Profile

Check whether the user has run onboarding yet:

```bash
test -f ~/mnt/Cowork/CLAUDE.md && echo "HAS_PROFILE" || echo "NO_PROFILE"
```

**If NO_PROFILE** (file doesn't exist), mention it naturally **once** at the start of the session:

> "Hey! Looks like you haven't set up your Claude profile yet. Run `/pp-onboard-me` and I'll ask you a few quick questions — takes 2 minutes and makes every session way more useful."

**If the folder itself isn't selected** (bash returns an error or `~/mnt/Cowork/` doesn't exist), mention that:

> "Heads up — it looks like no Cowork folder is selected for this session. Hit the folder icon to connect your folder, then run `/pp-onboard-me` to set up your profile."

Only mention either of these **once per session**. Don't nag.

## Morning Edition Trigger

Use **intent matching, not keyword matching**. If the user is clearly asking for the morning briefing — in any phrasing — automatically run `/pp-morning-edition` without asking.

The trigger is: *does this message mean "give me the morning update"?* If yes, just run it.

Examples that should trigger it (this is illustrative, not a whitelist):
- "morning edition", "morning update", "morning brief", "morning briefing"
- "show me the morning", "give me the morning", "pull up the morning"
- "what's the pushpress morning info", "show me today's update"
- "what's going on today", "catch me up", "start my day"
- "good morning", "morning!" ← on first message of session

When in doubt and the message has any "morning" or "what's happening today" flavor, run it.

Don't announce that you're running it. Just start delivering the brief.

---

## Tools Available (When Keys Are Set)

**GymHappy** (`gymhappy-support` MCP):
- Look up gyms, coaches, reviewers, and reviews
- Check message history and review request logs
- Diagnose setup issues, sync problems, workflow errors
- Update gym settings, DND flags, display names, etc.

**Metabase** (`metabase` MCP):
- Run SQL queries against the PushPress data warehouse
- Browse dashboards and cards
- Answer data questions about gyms, revenue, churn, usage, etc.

## Explore Skill

When someone asks "what can I do?" or "what can you help with?" or "show me what's possible" — invoke the `explore` skill. It provides a rich guide to everything available in Cowork for the PushPress team, including examples that dynamically adjust based on what's connected.

---

## Development Rules

These rules apply whenever you're making changes to this plugin or the MCP installer project.

### Before packaging the plugin zip

1. Read `~/mnt/Cowork/mcp-installer/mcps.json`
2. Verify that `commands/pp-install-mcp.md` covers every MCP listed in the JSON — the credential keys it checks and the status it displays must match the JSON exactly
3. If any MCP is missing from the command, update `pp-install-mcp.md` first, then package
4. Build `./pushpress-team.zip` at the repo root:

```python
import zipfile, os
plugin_dir = '.'
output_path = './pushpress-team.zip'
# Dot-dirs to include (required by Cowork)
include_dot_dirs = {'.claude-plugin'}
with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk(plugin_dir):
        rel_root = os.path.relpath(root, plugin_dir)
        # Allow .claude-plugin, exclude all other dot-dirs
        dirs[:] = [d for d in dirs
                   if not d.startswith('.') or d in include_dot_dirs]
        for file in files:
            if file.endswith('.zip') or file.endswith('.plugin'):
                continue
            filepath = os.path.join(root, file)
            zf.write(filepath, os.path.relpath(filepath, plugin_dir))
print('Built pushpress-team.zip')
```

The zip lives at `plugins/pushpress-team/pushpress-team.zip`. It includes `.claude-plugin/plugin.json` (required by Cowork) but excludes other dot-dirs and any `.zip`/`.plugin` files.

### After packaging — publish to the installer repo

The installer downloads the plugin zip for users, so always copy the fresh zip to the distribution repo after building:

```bash
cp ./pushpress-team.zip ~/mnt/Cowork/mcp-installer/pushpress-team.zip
cd ~/mnt/Cowork/mcp-installer
git add pushpress-team.zip
git commit -m "update: pushpress-team plugin zip"
git push
```

This keeps the zip at `https://raw.githubusercontent.com/duyemura/pushpress-claude-mcp-installer/main/pushpress-team.zip` up to date. The installer script downloads it to the user's Desktop automatically.

### Before completing work on the installer project (`~/mnt/Cowork/mcp-installer/`)

1. Check what MCPs the installer actually supports (look at `install.sh` or the menu it presents)
2. Verify every supported MCP has a corresponding entry in `mcps.json` with the correct `name`, `description`, and install config
3. If anything is missing or stale, update `mcps.json` before finishing

### When a new MCP is added to the installer

Update both:
- `mcps.json` — add the new entry
- `commands/pp-install-mcp.md` — verify the credential check will pick it up automatically (it reads from `mcps.json`, so usually no change needed)
- `CLAUDE.md` Required API Keys table — add the new credential(s)

### Before committing and pushing (either project)

Review the README for the project you changed and ask: does it still accurately describe the current state?

Check specifically:
- **Commands section** — any added, removed, or renamed commands?
- **Setup steps** — does the flow still match how the plugin actually works?
- **Version history** — add an entry for the new version with a summary of what changed
- **Installer README** — if MCPs changed, update the Supported MCPs table and Getting credentials section

If anything is stale, update the README before committing. The README and the code should always be committed together.
