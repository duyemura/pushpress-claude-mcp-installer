# PushPress Team Plugin

Internal Claude Cowork plugin for the PushPress team. Bundles GymHappy support tools, Metabase analytics, and an exploration guide to help the whole team get the most out of Cowork.

**Repo:** https://github.com/duyemura/pushpress-claude-plugin

The installable file is `pushpress-team.plugin` at the root of this repo — versioned alongside the source.

---

## What's included

### MCP Server Integrations

**GymHappy Support** — Full gym support tooling: look up gyms, diagnose messaging issues, check setup checklists, view review history, manage account settings, and more.

**Metabase** — Query the PushPress data warehouse in plain English. Browse dashboards, run analytics queries, and combine data with Slack, Notion, and Gmail.

**GitHub (PushPress Code)** — Read-only access to PushPress source code. Powers the `/pp-bug-check` command for CX triage. Each person creates their own Fine-Grained PAT with read-only permissions — no shared secrets, no write access.

### Commands

**`/pp-install-mcp`** — Check which MCPs are connected (✅/❌ per integration) and get the one-command Terminal installer to add any that are missing to Claude Desktop. Run this first after installing the plugin.

**`/pp-morning-edition`** — Your daily PushPress briefing. Pulls company Slack updates, a metrics snapshot, a Cowork tip, and a message from leadership — all in one place.

**`/pp-bug-check`** — CX bug triage tool. Describe a customer-reported issue and Claude searches the PushPress codebase, checks recent PRs, and gives a plain-English verdict: bug, working as designed, or needs engineering review. Requires the GitHub MCP.

### Skills

**`explore`** — A comprehensive guide to everything possible in Cowork. Triggered when you say things like "what can you do?" or "give me ideas." Dynamically adjusts based on which tools are connected.

### Config Files (editable by Dan)

**`config/morning-brief.md`** — Controls what the Morning Edition pulls. Edit Slack channels, CEO message source, metrics source, and standing PushPress context here. Repackage after editing.

**`config/cowork-tips.md`** — The rotating daily Cowork tips surfaced in the Morning Edition. Add new tips at the bottom anytime.

**`config/pushpress-company.md`** — Stable company identity layer: mission, story, products, tenets, vision, 2026 Annual Plan, teams, tools, internal language, and key metrics. Pre-seeded context for every session.

**`config/pushpress-strategy.md`** — Living planning layer: Q1 OKRs, Annual Plan targets, and Strategic Initiatives. Update each quarter.

**`config/pushpress-icp.md`** — Sales and marketing context: ICP tiers (Power User, Core, Emerging), scoring rubric, and customer profile data.

**`config/pushpress-competitors.md`** — Battle cards for all major competitors: Wodify, MindBody, Glofox, ZenPlanner, Wellness Living, Chalk it Pro/BLG, and Kilo. Includes win/lose reasons, pricing, and objection handling. Update as competitive landscape shifts.

**`config/pushpress-people.md`** — Org chart and team directory. Executive team, department structure, and key personnel by function. Update when org changes occur.

---

## Setup

### 1. Install the plugin

Open Cowork, go to Plugins, and install `pushpress-team.plugin` from this repo.

### 2. Check your MCP status in Cowork

After installation, start a new Cowork session and run:

```
/pp-install-mcp
```

This shows which MCPs are already connected and which are missing credentials.

### 3. Install missing MCPs into Claude Desktop

If any MCPs are missing, run this in **Terminal** (Cmd+Space → "Terminal"):

```bash
curl -fsSL https://raw.githubusercontent.com/duyemura/pushpress-claude-mcp-installer/main/install.sh | bash
```

The installer handles everything — including installing Node.js if you don't have it. No Python, Homebrew, or Xcode needed. It walks you through entering credentials, verifies they work, and updates Claude Desktop automatically. Backs up your config before making any changes.

### 4. Restart Claude Desktop and Cowork

After the installer runs, restart Claude Desktop, then restart Cowork. Run `/pp-install-mcp` again to confirm everything is green.

---

## Connected app integrations

The following can be connected via Cowork's MCP connector marketplace (no keys needed — just connect through the UI):

- **Gmail** — Search emails, draft responses, find forgotten follow-ups
- **Google Calendar** — Check your schedule, create events, find free time
- **Notion** — Search docs, read wikis, create pages
- **Slack** — Search messages, read threads, draft messages
- **Google Drive** — Search and read Docs, Sheets, and other files

---

## Example prompts

Once set up, try things like:

- *"/pp-morning-edition"* — Start your day with the full PushPress briefing
- *"What can you do?"* — Get a full tour of your connected tools
- *"/pp-install-mcp"* — Check MCP status and get setup instructions
- *"Look up CrossFit South End — why aren't their members getting review requests?"*
- *"What are our top 25 gyms by MRR right now?"*
- *"Pull top gyms from Metabase, then search Slack to see which ones the CEO has mentioned recently"*
- *"Find gyms that churned in the last 90 days — do we have any Notion notes on why they left?"*

---

## Version history

- **1.2.0** — Added `/pp-bug-check` command for CX bug triage. Added GitHub MCP (read-only) to plugin and installer. Each user creates their own Fine-Grained PAT — no shared tokens.
- **1.1.0** — Replaced Python MCP installer with zero-dependency bash script (`install.sh`). Auto-installs Node.js if needed — no Python, Homebrew, or Xcode required. Updated `/pp-install-mcp` command and session start check to remove Python dependency.
- **1.0.0** — Switched metrics source in `config/morning-brief.md` from live Metabase to a pre-pulled Notion page (`📊 PushPress Daily Metrics Snapshot`). A Cowork scheduled task (`pp-daily-metrics-snapshot`) now runs at 1:30 AM daily: pulls WBR metrics from Metabase, updates the Notion page, and posts a snapshot to #morning-edition in Slack. The morning edition skill reads from Notion, so the whole team gets metrics without needing Metabase credentials.
- **0.9.0** — Added five team context files to `config/`: `pushpress-company.md` (identity, products, tools, language), `pushpress-strategy.md` (Q1 OKRs, annual plan), `pushpress-icp.md` (ICP tiers and scoring), `pushpress-competitors.md` (battle cards for 7 competitors), and `pushpress-people.md` (org chart and team directory). Pre-seeds every Cowork session with PushPress tribal knowledge.
- **0.8.0** — Replaced /pp-setup-keys, /pp-setup-metabase, /pp-setup-gymhappy, /pp-install-gymhappy with unified /pp-install-mcp command. Shows live MCP status and routes to curl installer for Claude Desktop setup. Added mcps.json as canonical MCP registry (shared with installer project). CLAUDE.md session check now reads mcps.json dynamically. Moved pushpress-team.plugin inside repo.
- **0.7.0** — /pp-setup-gymhappy generates `setup/install-gymhappy-mcp.py` in the Cowork folder for one-command Terminal setup.
- **0.6.1** — Added /pp-setup-metabase with guided setup and one-click Slack request to #support-data.
- **0.6.0** — Added /pp-morning-edition with Slack digests, metrics snapshot, CEO message, and Cowork tips. Added config/morning-brief.md and config/cowork-tips.md.
- **0.5.1** — Renamed /setup-keys to /pp-setup-keys for consistent pp- prefix.
- **0.5.0** — Initial release with GymHappy MCP, Metabase MCP, /pp-setup-keys, /pp-install-gymhappy, explore skill.
